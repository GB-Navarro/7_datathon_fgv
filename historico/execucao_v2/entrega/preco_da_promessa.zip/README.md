# O preço da promessa

Pesquisa implementada para o 7º Datathon de Moedas Digitais da FGV EESP. Estuda fidelidade, custos e condições de negociação 24/7 do PAXG contra uma referência de ouro e os ETFs GLD/GLDM.

## Entrega e resultados

- [Apresentação final, 10 slides em PDF](slides/entrega.pdf).
- [Pacote para entrega e reprodução](entrega/preco_da_promessa.zip), com código, scripts TXT, parâmetros, testes, tabelas agregadas e figuras.
- [Interpretação dos resultados](results/INTERPRETACAO.md) e [registro numérico rastreável](results/RESULTS.md).
- [Tabelas e figuras](results/); [claims.csv](results/claims.csv) liga cada headline à sua origem.
- [Integridade do pipeline](results/QA_integrity.json), [testes executados](results/pytest.xml) e [manifesto de figuras](results/figure_manifest.json).

As análises foram executadas com dados reais na janela semiaberta **28/08/2020 12:00 UTC a 08/11/2026 00:00 UTC**. O primário tem **36.572 horas e 301 fins de semana válidos**, após exclusões explícitas dos 323 candidatos. Esses números são desta execução, rastreáveis nos resultados.

A mediana absoluta foi aproximadamente **36,4 bps log em horários comuns** e **48,4 bps log na reabertura**. A simulação principal avaliou **44 operações** e encontrou saldo médio de aproximadamente **−40,0 bps após os custos modelados, antes de custos financeiros desconhecidos**. Outros sinais sem preço completo continuam identificados no ledger; não foram declarados oportunidades inexistentes.

O equilíbrio de custo-base é **9,3 meses contra GLD e 37,2 contra GLDM**, condicionado a custos do token supostos, taxas/spread corrente dos ETFs, contas já em USD e comparação antes de impostos. Não é recomendação de investimento nem resultado universal entre produtos.

O critério de 78 trajetórias conjuntas para cenários anuais não foi atingido: houve 55. A saída aplicada é a sensibilidade determinística prevista no plano. O ramo de reamostragem conjunta está implementado e testado, mas não foi apresentado como resultado de mercado com amostra insuficiente. Não houve identificação causal de competição ou infraestrutura, e o intervalo da tendência inclui zero.

## Reproduzir

Requisitos: Python 3.11 e Node >=20. No Windows, a coleta usa `npx.cmd`; não exige alterar a política de execução do PowerShell. As fontes principais não exigem chave paga. Manter acesso de rede e espaço para os caches.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run_all.py --all
```

Com as dependências já instaladas, `python run_all.py --all` executa coleta, construção dos painéis, minutos, análises, gráficos/PDF, testes e empacotamento. Na primeira coleta, `npx` obtém a versão fixada do downloader. Fontes podem impor limites, falhar ou revisar dados; os brutos locais e hashes permitem preservar a execução.

Depois da primeira execução completa, a repetição abaixo usa somente os caches locais e falha se um arquivo necessário estiver ausente ou tiver hash alterado:

```powershell
python run_all.py --all --offline
```

Etapas individuais:

```powershell
python run_all.py --fetch --build
python run_all.py --minutes
python run_all.py --analyze --figures
python run_all.py --package
python -m pytest -q
```

`--package` também executa os testes e a validação de integridade. O pacote público não contém os brutos: extraí-lo em outra máquina exige uma primeira coleta online. O relatório de downloads com URLs, datas e hashes é [download_manifest.jsonl](results/download_manifest.jsonl).

## Premissas e identificação da equipe

[config/params.json](config/params.json) contém as escolhas analíticas. O instante e o hash do congelamento estão em [config_frozen.json](results/config_frozen.json); alterações posteriores de premissas são recusadas pelo runner. Para outra rodada, preserve esta execução e versione uma cópia separada, em vez de sobrescrever silenciosamente seus resultados.

Nome da equipe e integrantes podem ser informados em [config/presentation.json](config/presentation.json), sem alterar os parâmetros da análise. Depois, execute `python run_all.py --figures --package`. Não foram inventados nomes ou vínculos para a capa.

## Organização

```text
run_all.py               orquestração das etapas
src/common.py            configuração, hashes e unidades
src/fetch.py             aquisições e cache
src/panel.py             calendário e painéis sem preenchimento indevido
src/trades.py            sinais, preços de minuto e trajetórias
src/statistics.py        P&L, cruzamentos e bootstrap semanal
src/analysis.py          tabelas, cenários, claims e interpretação
src/quality.py           referência independente e integridade
src/report.py            figuras, PDF e pacote
tests/                   testes sem rede, com casos sintéticos declarados
config/                  premissas, fontes e apresentação
data/raw/                brutos locais, não distribuídos
data/interim/, panel/    dados processados locais, não distribuídos
results/                 saídas, logs, auditorias e figuras
slides/entrega.pdf       apresentação
scripts_txt/             cópias dos scripts no formato solicitado
entrega/                 ZIP e manifesto de arquivos
```

## Ajustes necessários incorporados

1. Ouro sempre com volume/atividade preservados; barras sintéticas não identificam horário negociável. Bid/ask são unidos por timestamp.
2. Bitfinex USDT/USD fornece a referência monetária primária desde 2020; a sobreposição sistemática com Coinbase é publicada como robustez. Não se supõe USDC=USD.
3. Sinal de convergência usa closes de minuto concluídos; entrada só no minuto seguinte. Trajetória horária é comparada na mesma amostra nos três instantes.
4. Perdas, preços faltantes e custos desconhecidos permanecem explícitos; a amostra insuficiente aciona a redução prevista, sem baixar limiares depois dos resultados.

## Limites e dados

Preços OHLC não garantem execução simultânea, liquidez ou acesso a short. Spread do token, taxas e slippage são cenários. Custos de empréstimo e financiamento não observados não viram zero. A inferência é exploratória; blocos semanais não resolvem dados ausentes ou custos omitidos. As conclusões não representam todo ouro tokenizado ou o custo final de um investidor brasileiro.

O ZIP exclui dados brutos, painéis de preço e ledgers detalhados com cotações de provedores. Há instruções de aquisição e estatísticas próprias. Leia os termos de cada fonte antes de redistribuir dados. A validação de ouro contra GLD é um diagnóstico de compatibilidade de referência, não uma prova de equivalência de instrumentos.

## Documentação

- [Plano da equipe](<projeto_humanos (1).md>) e [especificação técnica](<projeto_agentes (1).md>).
- [Auditoria crítica](AUDITORIA.md), [fontes verificadas](auditoria/fontes_verificadas.md) e [viabilidade dos dados](auditoria/VIABILIDADE_DADOS.md).
- [Versões originais recebidas](historico/) e [regulamento consultado](auditoria/fontes/regulamento_fgv_2026.pdf).

A entrega foi preparada localmente. Nenhuma operação financeira, comunicação com a organização ou submissão externa foi feita automaticamente.
